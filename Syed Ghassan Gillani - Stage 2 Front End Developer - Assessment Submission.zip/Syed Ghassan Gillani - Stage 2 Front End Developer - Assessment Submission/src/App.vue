<template>
  <Dashboard v-if="currentPage === 'dashboard'" @changePage="changePage" />
  <AddRecord v-else-if="currentPage === 'addRecord' && currentStep === 1" @goToStep="goToStep" />
  <AddRecordStep2 v-else-if="currentPage === 'addRecord' && currentStep === 2" @goToStep="goToStep" />
  <AddRecordStep3 v-else-if="currentPage === 'addRecord' && currentStep === 3" @goToStep="goToStep" />
</template>

<script setup>
import { ref } from 'vue'
import Dashboard from './views/Dashboard.vue'
import AddRecord from './views/AddRecord.vue'
import AddRecordStep2 from './views/AddRecordStep2.vue'
import AddRecordStep3 from './views/AddRecordStep3.vue'

const currentPage = ref('dashboard')
const currentStep = ref(1)

const changePage = (page) => {
  currentPage.value = page
  currentStep.value = 1 // Reset to step 1 when navigating to add record
}

const goToStep = (step) => {
  if (step === 'dashboard') {
    currentPage.value = 'dashboard'
    currentStep.value = 1
  } else {
    currentStep.value = step
  }
}
</script>
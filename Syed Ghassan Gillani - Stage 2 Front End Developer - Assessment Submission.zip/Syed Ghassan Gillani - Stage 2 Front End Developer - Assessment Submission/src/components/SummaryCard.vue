<template>
  <div class="bg-white rounded-md shadow-md px-6 py-4 min-w-[220px] text-gray-800">
    <slot />
  </div>
</template>
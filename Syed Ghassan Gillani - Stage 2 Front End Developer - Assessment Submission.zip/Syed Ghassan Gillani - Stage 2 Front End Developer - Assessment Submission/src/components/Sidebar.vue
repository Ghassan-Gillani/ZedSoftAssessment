<template>
  <aside 
    class="w-16 hover:w-56 bg-white shadow-lg h-screen flex flex-col py-8 transition-all duration-300 ease-in-out group"
    @mouseenter="isExpanded = true"
    @mouseleave="isExpanded = false"
  >
    <!-- Logo -->
    <div class="flex items-center justify-center mb-12">
      <div class="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-500 rounded-lg flex items-center justify-center text-2xl font-bold text-white shadow-md">
        NF
      </div>
    </div>
    <!-- Menu -->
    <nav class="flex flex-col gap-2 px-4">
      <SidebarItem icon="dashboard" label="Dashboard" :active="true" :expanded="isExpanded" />
      <SidebarItem icon="folder" label="Records" :expanded="isExpanded" />
      <SidebarItem icon="user" label="My Account" :expanded="isExpanded" />
      <SidebarItem icon="users" label="Users" :expanded="isExpanded" />
      <SidebarItem icon="lock-closed" label="Security" :expanded="isExpanded" />
      <SidebarItem icon="light-bulb" label="Change Theme" :expanded="isExpanded" />
      <SidebarItem icon="information-circle" label="Info" :expanded="isExpanded" />
    </nav>
  </aside>
</template>

<script setup>
import { ref } from 'vue'
import SidebarItem from './SidebarItem.vue'

const isExpanded = ref(false)
</script>
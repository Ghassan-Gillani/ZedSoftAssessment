<template>
  <div 
    class="bg-white rounded-md shadow-md px-6 py-4 min-w-[220px] text-gray-800 cursor-pointer hover:shadow-lg transition-all duration-200 hover:bg-blue-50"
    @click="$emit('click')"
  >
    <slot />
  </div>
</template>

<script setup>
defineEmits(['click'])
</script>
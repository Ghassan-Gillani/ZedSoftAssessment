<template>
  <div class="flex min-h-screen bg-gray-50">
    <Sidebar />
    <main class="flex-1 p-12">
      <!-- Dashboard Header -->
      <div class="flex items-center mb-8">
        <svg class="w-10 h-10 text-blue-600 mr-3" fill="currentColor" viewBox="0 0 24 24">
          <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8v-10h-8v10zm0-18v6h8V3h-8z"/>
        </svg>
        <h1 class="text-3xl font-bold text-blue-700">Dashboard</h1>
      </div>

      <!-- Summaries Section -->
      <section class="mb-10">
        <h2 class="text-xl font-semibold text-gray-800 mb-6">Summaries</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <SummaryCard>Total Records</SummaryCard>
          <SummaryCard>Records Pending</SummaryCard>
          <SummaryCard>Processes Pending</SummaryCard>
          <SummaryCard>Submitted Today</SummaryCard>
          <SummaryCard>Submitted this Month</SummaryCard>
        </div>
      </section>

      <!-- Quick Menu Section -->
      <section>
        <h2 class="text-xl font-semibold text-gray-800 mb-6">Quick Menu</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <QuickMenuCard @click="$emit('changePage', 'addRecord')">Add a new record</QuickMenuCard>
          <QuickMenuCard>View past records</QuickMenuCard>
          <QuickMenuCard>Process new records</QuickMenuCard>
        </div>
      </section>
    </main>
  </div>
</template>

<script setup>
import Sidebar from '../components/Sidebar.vue'
import SummaryCard from '../components/SummaryCard.vue'
import QuickMenuCard from '../components/QuickMenuCard.vue'

defineEmits(['changePage'])
</script>
<template>
  <div class="flex min-h-screen bg-gray-50">
    <Sidebar />
    <div class="flex-1 flex flex-col">
      <!-- Header -->
      <header class="bg-white shadow-sm px-8 py-4 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
            </svg>
          </div>
          <h1 class="text-2xl font-bold text-blue-700">Add Record</h1>
        </div>
        <div class="flex items-center gap-4">
          <button class="text-blue-600 hover:text-blue-800">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
          </button>
          <button 
            @click="$emit('goToStep', 'dashboard')"
            class="text-red-500 hover:text-red-700"
          >
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>
      </header>

      <!-- Main Content -->
      <main class="flex-1 p-8">
        <div class="max-w-4xl mx-auto">
          <!-- Progress Indicator -->
          <div class="flex items-center justify-center mb-8">
            <div class="flex items-center">
              <div class="w-10 h-10 bg-gray-400 rounded-full flex items-center justify-center text-white font-semibold">1</div>
              <div class="w-16 h-1 bg-gray-300 mx-2"></div>
              <div class="w-10 h-10 bg-gray-400 rounded-full flex items-center justify-center text-white font-semibold">2</div>
              <div class="w-16 h-1 bg-gray-300 mx-2"></div>
              <div class="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold">3</div>
            </div>
          </div>

          <!-- Form Title -->
          <h2 class="text-3xl font-bold text-center mb-8">Seals</h2>

          <!-- Form -->
          <div class="bg-white rounded-lg shadow-md p-8">
            <!-- Seal Tabs -->
            <div class="flex gap-2 mb-6">
              <button class="px-4 py-2 bg-blue-600 text-white rounded-md font-medium">Seal 1</button>
              <button class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md font-medium hover:bg-gray-300">+ Add Seal</button>
            </div>

            <!-- Seal 1 Section -->
            <div class="space-y-6">
              <!-- Seal Fields -->
              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Reception Date
                  </label>
                  <input 
                    v-model="formData.receptionDate"
                    type="text" 
                    placeholder="DD/MM/YYYY"
                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Seal State
                  </label>
                  <div class="relative">
                    <select 
                      v-model="formData.sealState"
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
                    >
                      <option value="">Select state</option>
                      <option value="Intact">Intact</option>
                      <option value="Damaged">Damaged</option>
                      <option value="Broken">Broken</option>
                    </select>
                    <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                      <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>

              <!-- File Upload Section -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Images
                </label>
                <div class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 4V2a1 1 0 011-1h8a1 1 0 011 1v2m-9 0h10m-10 0a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V6a2 2 0 00-2-2"/>
                  </svg>
                  <p class="mt-2 text-sm text-gray-600">Drag files here to upload.</p>
                  <p class="mt-1 text-sm text-gray-500">Or</p>
                  <button type="button" class="mt-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                    Select Files
                  </button>
                </div>

                <!-- File List -->
                <div class="mt-4 space-y-2">
                  <div class="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                    <div class="flex items-center gap-3">
                      <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                      </svg>
                      <span class="text-sm text-gray-700">van 2 rr.xls</span>
                      <span class="text-xs text-gray-500">(121.00 KB)</span>
                    </div>
                    <div class="flex items-center gap-2">
                      <button class="text-blue-600 hover:text-blue-800">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                        </svg>
                      </button>
                      <button class="text-red-500 hover:text-red-700">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                      </button>
                    </div>
                  </div>
                  <div class="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                    <div class="flex items-center gap-3">
                      <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                      </svg>
                      <span class="text-sm text-gray-700">van 2 rr.xls</span>
                      <span class="text-xs text-gray-500">(121.00 KB)</span>
                    </div>
                    <div class="flex items-center gap-2">
                      <button class="text-blue-600 hover:text-blue-800">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                        </svg>
                      </button>
                      <button class="text-red-500 hover:text-red-700">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Sample Section -->
            <div class="mt-8 pt-8 border-t border-gray-200">
              <h3 class="text-xl font-semibold mb-6">Sample 1-A</h3>
              
              <div class="space-y-6">
                <!-- Sample Fields -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                      Sample Date
                    </label>
                    <input 
                      v-model="formData.sampleDate"
                      type="text" 
                      placeholder="DD/MM/YYYY"
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                      Sample Time
                    </label>
                    <div class="relative">
                      <input 
                        v-model="formData.sampleTime"
                        type="text" 
                        value="15:00:00"
                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-8"
                      />
                      <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                        <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Sample Description
                  </label>
                  <textarea 
                    v-model="formData.sampleDescription"
                    rows="3"
                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter sample description..."
                  ></textarea>
                </div>

                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Analyses <span class="text-red-500">*</span>
                  </label>
                  <div class="relative">
                    <select 
                      v-model="formData.analyses"
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
                    >
                      <option value="">Select analyses</option>
                      <option value="DNA Analysis">DNA Analysis</option>
                      <option value="Chemical Analysis">Chemical Analysis</option>
                      <option value="Physical Analysis">Physical Analysis</option>
                    </select>
                    <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                      <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                      </svg>
                    </div>
                  </div>
                </div>

                <div>
                  <button type="button" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                    + Add Sample
                  </button>
                </div>
              </div>
            </div>

            <!-- Navigation Buttons -->
            <div class="flex justify-end pt-8 mt-8 border-t border-gray-200">
              <div class="flex gap-4">
                <button 
                  type="button"
                  @click="$emit('goToStep', 2)"
                  class="bg-green-600 text-white px-8 py-3 rounded-md hover:bg-green-700 transition-colors font-medium"
                >
                  Previous
                </button>
                <button 
                  type="submit"
                  @click="handleFinish"
                  class="bg-blue-600 text-white px-8 py-3 rounded-md hover:bg-blue-700 transition-colors font-medium"
                >
                  Finish
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup>
import { reactive } from 'vue'
import Sidebar from '../components/Sidebar.vue'

// Form data
const formData = reactive({
  receptionDate: '',
  sealState: '',
  sampleDate: '',
  sampleTime: '15:00:00',
  sampleDescription: '',
  analyses: ''
})

// Handle finish
const handleFinish = () => {
  console.log('Form completed:', formData)
  // Emit event to go back to dashboard
  emit('goToStep', 'dashboard')
}

const emit = defineEmits(['goToStep'])
</script> 
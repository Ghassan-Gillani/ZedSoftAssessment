<template>
  <div class="flex min-h-screen bg-gray-50">
    <Sidebar />
    <div class="flex-1 flex flex-col">
      <!-- Header -->
      <header class="bg-white shadow-sm px-8 py-4 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
            </svg>
          </div>
          <h1 class="text-2xl font-bold text-blue-700">Add Record</h1>
        </div>
        <div class="flex items-center gap-4">
          <button class="text-blue-600 hover:text-blue-800">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
          </button>
          <button 
            @click="$emit('goToStep', 'dashboard')"
            class="text-red-500 hover:text-red-700"
          >
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>
      </header>

      <!-- Main Content -->
      <main class="flex-1 p-8">
        <div class="max-w-4xl mx-auto">
          <!-- Progress Indicator -->
          <div class="flex items-center justify-center mb-8">
            <div class="flex items-center">
              <div class="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold">1</div>
              <div class="w-16 h-1 bg-gray-300 mx-2"></div>
              <div class="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center text-gray-500 font-semibold">2</div>
              <div class="w-16 h-1 bg-gray-300 mx-2"></div>
              <div class="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center text-gray-500 font-semibold">3</div>
            </div>
          </div>

          <!-- Form Title -->
          <h2 class="text-3xl font-bold text-center mb-8">Create New Record</h2>

          <!-- Error Alert -->
          <div v-if="showError" class="mb-6 bg-red-50 border border-red-200 rounded-md p-4">
            <div class="flex">
              <div class="flex-shrink-0">
                <svg class="h-5 w-5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"/>
                </svg>
              </div>
              <div class="ml-3">
                <h3 class="text-sm font-medium text-red-800">Please fill in all required fields</h3>
                <div class="mt-2 text-sm text-red-700">
                  <ul class="list-disc list-inside">
                    <li v-for="error in validationErrors" :key="error">{{ error }}</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <!-- Form -->
          <div class="bg-white rounded-lg shadow-md p-8">
            <form @submit.prevent="handleSubmit" class="space-y-6">
              <!-- Row 1 -->
              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Date received <span class="text-red-500">*</span>
                  </label>
                  <input 
                    v-model="formData.dateReceived"
                    type="text" 
                    placeholder="DD/MM/YYYY"
                    :class="[
                      'w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent',
                      errors.dateReceived ? 'border-red-300' : 'border-gray-300'
                    ]"
                  />
                  <p v-if="errors.dateReceived" class="mt-1 text-sm text-red-600">{{ errors.dateReceived }}</p>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Time received <span class="text-red-500">*</span>
                  </label>
                  <input 
                    v-model="formData.timeReceived"
                    type="text" 
                    :class="[
                      'w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent',
                      errors.timeReceived ? 'border-red-300' : 'border-gray-300'
                    ]"
                  />
                  <p v-if="errors.timeReceived" class="mt-1 text-sm text-red-600">{{ errors.timeReceived }}</p>
                </div>
              </div>

              <!-- Row 2 -->
              <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Customer title <span class="text-red-500">*</span>
                  </label>
                  <div class="relative">
                    <select 
                      v-model="formData.customerTitle"
                      :class="[
                        'w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none',
                        errors.customerTitle ? 'border-red-300' : 'border-gray-300'
                      ]"
                    >
                      <option value="">Select title</option>
                      <option value="Mr.">Mr.</option>
                      <option value="Mrs.">Mrs.</option>
                      <option value="Ms.">Ms.</option>
                      <option value="Dr.">Dr.</option>
                    </select>
                    <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                      <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                      </svg>
                    </div>
                  </div>
                  <p v-if="errors.customerTitle" class="mt-1 text-sm text-red-600">{{ errors.customerTitle }}</p>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Customer name
                  </label>
                  <input 
                    v-model="formData.customerName"
                    type="text" 
                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    First name
                  </label>
                  <input 
                    v-model="formData.firstName"
                    type="text" 
                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <!-- Row 3 -->
              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Date of birth
                  </label>
                  <input 
                    v-model="formData.dateOfBirth"
                    type="text" 
                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">
                    Sex
                  </label>
                  <div class="relative">
                    <select 
                      v-model="formData.sex"
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
                    >
                      <option value="">Select sex</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                    <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                      <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Navigation Button -->
              <div class="flex justify-end pt-6">
                <button 
                  type="submit"
                  class="bg-blue-600 text-white px-8 py-3 rounded-md hover:bg-blue-700 transition-colors font-medium"
                >
                  Next
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import Sidebar from '../components/Sidebar.vue'

// Form data
const formData = reactive({
  dateReceived: '',
  timeReceived: '15:00:00',
  customerTitle: '',
  customerName: '',
  firstName: '',
  dateOfBirth: '',
  sex: ''
})

// Error states
const errors = reactive({
  dateReceived: '',
  timeReceived: '',
  customerTitle: ''
})

const showError = ref(false)
const validationErrors = ref([])

// Validation function
const validateForm = () => {
  let isValid = true
  validationErrors.value = []
  
  // Reset errors
  Object.keys(errors).forEach(key => {
    errors[key] = ''
  })

  // Validate required fields
  if (!formData.dateReceived.trim()) {
    errors.dateReceived = 'Date received is required'
    validationErrors.value.push('Date received is required')
    isValid = false
  }

  if (!formData.timeReceived.trim()) {
    errors.timeReceived = 'Time received is required'
    validationErrors.value.push('Time received is required')
    isValid = false
  }

  if (!formData.customerTitle) {
    errors.customerTitle = 'Customer title is required'
    validationErrors.value.push('Customer title is required')
    isValid = false
  }

  return isValid
}

// Handle form submission
const handleSubmit = () => {
  if (validateForm()) {
    // Form is valid, proceed to next step
    console.log('Form is valid, proceeding to next step...')
    // Emit event to go to step 2
    emit('goToStep', 2)
  } else {
    // Show error alert
    showError.value = true
    // Hide error after 5 seconds
    setTimeout(() => {
      showError.value = false
    }, 5000)
  }
}

const emit = defineEmits(['goToStep'])
</script> 